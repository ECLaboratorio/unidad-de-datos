Puntuaciones de los capítulos de las siguientes series extraídas de la web IMBD

<ul>
	<li>The Walking Dead</li>
	<li>Juego de tronos</li>
	<li>Homeland</li>
	<li>Anatomía de Grey</li>
	<li>Black Mirror</li>
	<li>Stranger Things</li>
	<li>Breaking Bad</li>
	<li>Orange Is the New Black</li>
	<li>The Good Wife</li>
	<li>Cómo conocí a vuestra madre</li>
	<li>Lost in Space</li>
	<li>Narcos</li>
	<li>Friends</li>
	<li>House of Cards</li>
	<li>Perdidos</li>
</ul>